Task 2 - Resume Generator 1

1. Add more fields in the form -
    1. Contact - Email and Phone
    2. LinkedIn Profile anf Github Profile
    3. Take a .png file (your photograph) from internet(ex- https://quolla.com/images/logo.png) as input.
    4. Add option to add multiple education points. Number of educations should not be fixed but dynamic.
2. Render already existing fields and above fields in the form a resume on the right side of the page.
    1. Dyanmically update data from form in the template on 'keypress'
    2. Make sure the template renders the validated data
3. Miscellaneous -
    1. Add show/hide password button
    2. Error of form validation comes in 'alert' format. Remove it and add error just below the input field in red color.