var addButton = document.getElementById("addButton");
var toDoList = document.getElementById("toDoList");
var todoInput = document.getElementById("todoInput");
var deleteAll = document.getElementById("deleteAll");
var tododate = document.getElementById("tododate");
function markAsDone(event){

    event.target.parentElement.classList.add("markAsDone")
}

function addToDoList(){
    var toDoMain = document.createElement('div')
    toDoMain.id = String(Math.random());
    // toDoMain.classList.add(uniqueId);

    var todo = document.createElement('div');
    todo.appendChild(document.createTextNode(todoInput.value));
    toDoMain.appendChild(todo);

    var tododate = document.createElement('div');
    todo.appendChild(document.createTextNode(tododate.value));
    toDoMain.appendChild(tododate);
    
    var todoX = document.createElement('button');
    todoX.appendChild(document.createTextNode('X'));
    todoX.addEventListener('click', deltodo)
    toDoMain.appendChild(todoX);
    // todoX.setAttribute('id', uniqueId)

    var todoEdit = document.createElement('button');
    todoEdit.appendChild(document.createTextNode('Edit'));
    toDoMain.appendChild(todoEdit);

    var todoDone = document.createElement('button');
    todoDone.appendChild(document.createTextNode('Done'));

    var todoprog = document.createElement('button');
    todoprog.appendChild(document.createTextNode('Prog'));

    toDoMain.appendChild(todoDone);
    toDoMain.appendChild(todoprog);
    todoDone.addEventListener("click", markAsDone );


    toDoList.appendChild(toDoMain);
    todoInput.value = ''
}
// function markAsDone{

// }
function delall(){
    toDoList.innerHTML = ''
}
function deltodo(event){
    let uniqueId = event.target.id
    var referenceTools = document.getElementsByClassName(uniqueId)[0] 
    referenceTools.remove()
    event.target.remove()
}
addButton.addEventListener("click", addToDoList );
deleteAll.addEventListener("click", delall );
